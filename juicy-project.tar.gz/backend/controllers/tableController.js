const Table = require('../models/Table');
const Order = require('../models/Order');

// @desc    Get all tables
// @route   GET /api/tables
// @access  Private
exports.getAllTables = async (req, res) => {
  try {
    const { status, floor, location, isActive } = req.query;

    const filter = {};
    if (status) filter.status = status;
    if (floor) filter.floor = floor;
    if (location) filter.location = location;
    if (isActive !== undefined) filter.isActive = isActive === 'true';

    const tables = await Table.find(filter)
      .populate('currentOrder', 'orderNo grandTotal orderStatus items')
      .populate('createdBy', 'name username')
      .sort({ displayOrder: 1, tableNumber: 1 });

    res.json({
      success: true,
      count: tables.length,
      tables
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to fetch tables',
      error: error.message
    });
  }
};

// @desc    Get single table
// @route   GET /api/tables/:id
// @access  Private
exports.getTableById = async (req, res) => {
  try {
    const table = await Table.findById(req.params.id)
      .populate('currentOrder')
      .populate('createdBy', 'name username');

    if (!table) {
      return res.status(404).json({
        success: false,
        message: 'Table not found'
      });
    }

    res.json({
      success: true,
      table
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to fetch table',
      error: error.message
    });
  }
};

// @desc    Create new table
// @route   POST /api/tables
// @access  Private (Admin only)
exports.createTable = async (req, res) => {
  try {
    const {
      tableNumber,
      tableName,
      seatingCapacity,
      location,
      floor,
      shape,
      description
    } = req.body;

    // Check if table number already exists
    const existingTable = await Table.findOne({ tableNumber: tableNumber.toUpperCase() });
    if (existingTable) {
      return res.status(400).json({
        success: false,
        message: `Table ${tableNumber} already exists`
      });
    }

    const table = await Table.create({
      tableNumber: tableNumber.toUpperCase(),
      tableName,
      seatingCapacity,
      location,
      floor,
      shape,
      description,
      createdBy: req.user._id
    });

    res.status(201).json({
      success: true,
      message: 'Table created successfully',
      table
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to create table',
      error: error.message
    });
  }
};

// @desc    Update table
// @route   PUT /api/tables/:id
// @access  Private (Admin only)
exports.updateTable = async (req, res) => {
  try {
    const {
      tableNumber,
      tableName,
      seatingCapacity,
      location,
      floor,
      shape,
      description,
      isActive
    } = req.body;

    const table = await Table.findById(req.params.id);

    if (!table) {
      return res.status(404).json({
        success: false,
        message: 'Table not found'
      });
    }

    // Check if table is occupied
    if (table.status === 'Occupied' && !isActive) {
      return res.status(400).json({
        success: false,
        message: 'Cannot deactivate an occupied table'
      });
    }

    // Check if new table number already exists
    if (tableNumber && tableNumber.toUpperCase() !== table.tableNumber) {
      const existingTable = await Table.findOne({
        tableNumber: tableNumber.toUpperCase(),
        _id: { $ne: req.params.id }
      });

      if (existingTable) {
        return res.status(400).json({
          success: false,
          message: `Table ${tableNumber} already exists`
        });
      }
    }

    // Update fields
    if (tableNumber) table.tableNumber = tableNumber.toUpperCase();
    if (tableName) table.tableName = tableName;
    if (seatingCapacity) table.seatingCapacity = seatingCapacity;
    if (location) table.location = location;
    if (floor) table.floor = floor;
    if (shape) table.shape = shape;
    if (description !== undefined) table.description = description;
    if (isActive !== undefined) table.isActive = isActive;

    await table.save();

    res.json({
      success: true,
      message: 'Table updated successfully',
      table
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to update table',
      error: error.message
    });
  }
};

// @desc    Delete table
// @route   DELETE /api/tables/:id
// @access  Private (Admin only)
exports.deleteTable = async (req, res) => {
  try {
    const table = await Table.findById(req.params.id);

    if (!table) {
      return res.status(404).json({
        success: false,
        message: 'Table not found'
      });
    }

    // Check if table is occupied
    if (table.status === 'Occupied') {
      return res.status(400).json({
        success: false,
        message: 'Cannot delete an occupied table. Please complete or cancel the order first.'
      });
    }

    await Table.findByIdAndDelete(req.params.id);

    res.json({
      success: true,
      message: 'Table deleted successfully'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to delete table',
      error: error.message
    });
  }
};

// @desc    Update table status
// @route   PUT /api/tables/:id/status
// @access  Private
exports.updateTableStatus = async (req, res) => {
  try {
    const { status } = req.body;

    const table = await Table.findById(req.params.id);

    if (!table) {
      return res.status(404).json({
        success: false,
        message: 'Table not found'
      });
    }

    table.status = status;

    // If marking as available, clear current order
    if (status === 'Available') {
      table.currentOrder = null;
    }

    await table.save();

    res.json({
      success: true,
      message: 'Table status updated successfully',
      table
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to update table status',
      error: error.message
    });
  }
};

// @desc    Get table statistics
// @route   GET /api/tables/stats/summary
// @access  Private
exports.getTableStats = async (req, res) => {
  try {
    const totalTables = await Table.countDocuments({ isActive: true });
    const availableTables = await Table.countDocuments({ status: 'Available', isActive: true });
    const occupiedTables = await Table.countDocuments({ status: 'Occupied', isActive: true });
    const reservedTables = await Table.countDocuments({ status: 'Reserved', isActive: true });

    const occupancyRate = totalTables > 0
      ? ((occupiedTables / totalTables) * 100).toFixed(2)
      : 0;

    // Get active orders count
    const activeOrders = await Order.countDocuments({ orderStatus: { $in: ['Active', 'Ready'] } });

    res.json({
      success: true,
      stats: {
        totalTables,
        availableTables,
        occupiedTables,
        reservedTables,
        occupancyRate: parseFloat(occupancyRate),
        activeOrders
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to fetch table statistics',
      error: error.message
    });
  }
};
